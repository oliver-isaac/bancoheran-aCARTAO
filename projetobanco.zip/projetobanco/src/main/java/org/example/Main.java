package org.example;
import java.util.Scanner;



 public class Main {

     public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);

         System.out.println("===== SAFEBANK - CADASTRO DE CARTÃO =====\n");

         System.out.println("--- Digite os dados do Cartão de Crédito ---");

         System.out.print("Número do cartão: ");
         String numero = scanner.nextLine();

         System.out.print("Nome do titular: ");
         String titular = scanner.nextLine();

         System.out.print("Bandeira do cartão (Visa, Mastercard ou Elo): ");
         String bandeira = scanner.nextLine();

         System.out.print("Limite do cartão: ");
         double limite = scanner.nextDouble();
         scanner.nextLine();

         Cartaocredito cartaocredito = new Cartaocredito(
                 numero,
                 titular,
                 limite,
                 bandeira
         );

         System.out.println("\n--- Exibição dos dados ---");
         System.out.println("Titular (método herdado do pai): " + cartaocredito.gettitular());
         System.out.println("Limite (método da classe filha): R$ " + cartaocredito.getlimite());

         System.out.println("\n--- Informações completas ---");
         cartaocredito.exibirinfo();

         scanner.close();
 }
   }
