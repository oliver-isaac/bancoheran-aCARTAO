package org.example;

public class Cartaodebito extends Cartao {
    private double saldoconta;

    private String bandeira;

    public Cartaodebito(){}

    public Cartaodebito(String numerocartao,String titular,double saldoconta,String bandeira){
        super(numerocartao,titular);

        this.setsaldoconta(saldoconta);
        this.setbandeira(bandeira);
    }
    public double getSaldoconta(){
        return saldoconta;
    }
    public void setsaldoconta(double saldoconta){
        if(saldoconta < 0){
            System.out.println("saldo n pode ser negativo "+saldoconta);
        }else{
            this.saldoconta = saldoconta;
        }
    }
    public String bandeira(){
        return bandeira;
    }
    public void setbandeira(String bandeira){

        if( bandeira.equalsIgnoreCase("visa")||
            bandeira.equalsIgnoreCase("mastercard")||
            bandeira.equalsIgnoreCase("elo")){

                     this.bandeira = bandeira;
            }else{
            System.out.println("Erro : bandeira: "
                    + bandeira + "nao e aceitavel , use o cartao: visa, mastercad ou elo");
        }
        }

    @Override
    public void exibirinfo() {
        System.out.println("Bandeira: " + bandeira);
        System.out.println("Saldo em Conta: R$ "+saldoconta);
    }
}

