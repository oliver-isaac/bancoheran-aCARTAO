package org.example;

public class Cartao {
    private String numerocartao;
    private String titular;

    public Cartao(){}

    public Cartao (String numerocartao , String titular){
        this.numerocartao = numerocartao;
        this.titular = titular;

        }
        public String getnumerocartao(){
            return numerocartao;
    }
    public void setnumerocartao(String numerocartao){
        this.numerocartao = numerocartao;
    }
    public String gettitular(){
        return titular;
    }
    public void settitular(String titular){
        this.titular = titular;
    }
    public void exibirinfo(){
        System.out.println("numero do cartao: "
        +numerocartao);
        System.out.println("titular: "
        +titular);
    }
}
