package org.example;

import java.sql.SQLOutput;

public class Cartaocredito extends Cartao{
    private double limite;

    private String bandeira;

    public Cartaocredito(){}

    public Cartaocredito(String numerocartao , String titular, double limite,String bandeira){
        super(numerocartao,titular);

        this.setlimite(limite);
        this.setbandeira(bandeira);
    }
    public double getlimite(){
        return limite;
    }
    public void setlimite(double limite){
        if(limite < 0){
            System.out.println("erro: limite nao pode ser negativo" + limite);
        }else{
            System.out.println("limite guardado");
            this.limite = limite;
        }
    }
    public String getbandeira(){
        return bandeira;
    }
    public void setbandeira (String bandeira) {
        if (    bandeira.equalsIgnoreCase("visa") ||
                bandeira.equalsIgnoreCase("Mastercard")||
                bandeira.equalsIgnoreCase("elo")){
            this.bandeira = bandeira;

        }else{
            System.out.println("Erro : bandeira "
                    + bandeira + "nao e aceitavel , use o cartao: visa, mastercad ou elo");
        }

    }

    @Override
    public void exibirinfo() {
        super.exibirinfo();
        System.out.println("bandeira: "+bandeira);
        System.out.println("limite: R$ " + limite);
    }
}


